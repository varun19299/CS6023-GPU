# README

## Pseudocode

1. Read file, check if string is a word.
2. Save words into an array.
3. For a given N, generate the sliding window array, with count. (Can this be optimised?)
4. Bin this histogram.